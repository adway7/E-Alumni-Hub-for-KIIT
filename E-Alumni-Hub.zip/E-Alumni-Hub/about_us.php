<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>About Us</title>
<link rel="stylesheet" href="css/about_us.css" />

<?php
include_once"setting/aboutus_navigation.php";
?>
</head>

<body>
<div id="contact">
<p class="p1">Contact</p>
<p class="p2">Department Of Technology</p>
<p class="p3">KIIT University<br>
Patia, Bhubaneswar, Odisha, India
Pin: 751024<br>
Bhubaneswar<br><br></p>
<table>
<tr>
	<td>
			<p class="p2">Contact us at:</p>
			<p class="p3">Tel : +91 674 2725113</p>
	</td>		
	<td >
    <p class="p2">Email:</p>kiit@kiit.ac.in<p class="p3"></p><br /><br />
    <p class="p2">Our Social Pages:</p>
  <p class="p3"> <a href="https://www.facebook.com/KIITUniversity/">
   <img src="pictures/facebook1.png" width="40" height="40"></a> 
   <a href="https://www.instagram.com/KIITUniversity/">
   <img src="pictures/instagram1.png" width="55" height="40">
  </a> <a href="https://twitter.com/KIITUniversity">
  <img src="pictures/X.png" width="40" height="40"></a>
  <a href="https://www.linkedin.com/school/kiituniversity/">
  <img src="pictures/lnkdin.png" width="40" height="40"></a></p><br /><br />
    </td>
</tr>
</table>

</div>
<br><br><br>

<div id="history">
<p class="p1">KIIT e-Alumni Hub</p>
<p class="p3">The KIIT Alumni Association supervises the graduate programs in KIIT. 
	This includes administering the admission, appointment of Alumnis, Members reviews, 
	provision of financial assistance and assessment. </p><br />
<p class="p2">FUNCTION OF  e-Alumni Hub (e-AH)</p>
<p class="p3">The function of e-AH includes the following:
<ul class="ul2">
	<li>Promoting KIIT’s graduate programs</li>
	<li>Facilitate the appointment of Alumni's after graduation</li>
	<li>Oversees the provision of financial assistance</li>
	<li>Organises events for Alumnis </li>
	<li>Facilitate communication between Alumnis after graduation </li>
	<li>Coordinate the assessment for graduation purposes</li>
	<li>Organise activities to enhance graduate students research capabilities</li>
</ul>
</p>
<p class="p1">About KIIT Deemed to be University</p>
<p class="p3">Kalinga Institute of Industrial Technology (KIIT), a household name in the education sector, has become a sought-after destination in India for professional studies. It is admired all over for the quality of its academic courses, its community outreach work and as a university of compassion and humanitarianism. It has become a case study because no other educational institution in India has grown in its scope and scale as much as KIIT has in a short span of 25 years. Its incredible transformation is truly a journey from Soil to Silver.</p>

<p class="p3">KIIT started in 1992-93 as an Industrial Training Institution. However, 1997 is considered the base year for the University as undergraduate and postgraduate courses in Engineering, Management and Computer Applications were added. In 2007, many new schools were added to its umbrella – School of Law, Biotechnology, Medical Sciences, Dental Sciences, Nursing, Mass Communication, Film and Media, Fashion and KIIT International School. Since then, there has been no looking back! Today, KIIT offers professional education to around 40,000 students from across India. This includes 2000 international students from 65 countries. The alumni of KIIT, over a lakh of them, have made their mark in their respective careers in academics, corporate organizations, civil services and enterprise.</p>

<p class = "p3">One would find it difficult to imagine that such a celebrated institution with a global reputation was established by an unassuming humble being, Dr Achyuta Samanta, the Founder of KIIT and KISS, who started the institute with all of Rs 5000 as the initial investment. He had big dreams and a passion to make a difference. Dr Samanta started KIIT in two rented rooms with 12 students and 2 staff. The modest institution has now grown to incomprehensible propositions and is spread over a vast 36-square-kilometre academic township. Its 25 lush green campuses employ over 3000 eminent faculty and researchers and 15000 staff. KIIT and KISS together is a family of over a lakh people. The campus houses a 2600-bedded super speciality hospital, KIMS, a multi-storey central library, a central research facility, a 22-storey research and innovation wing, auditoriums – the largest one with 5000 seating capacity, 18 sports complexes, many international standard stadiums covering all sports, 30 food courts, and a rose garden. The institution takes pride in being the greenest campus in India.</p>

<p class="p3">It has received all accreditations and affiliations from prestigious national and international bodies such as the Accreditation Board for Engineering and Technology (ABET), USA and the Institution of Engineering and Technology, (IET), UK because of its quality research, innovation, and publications and citations.</p>
</div>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>KIIT Alumni Hub</title>
<link rel="stylesheet" href="css/header_navigationbar.css" />
<link rel="stylesheet" href="css/index.css" />
<?php
include_once"setting/index_navigation.php";
?>   

</head>
<body>
<br><br>
<div id="welcome">

<div class="slideshow-container">
<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img class="img" src="pictures/UMP.jpg"  width="100%" >
  <div class="text"><i>Linking to</i></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img class="img" src="pictures/friends.jpg" width="100%" >
  <div class="text"><i>Old Friends</i></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img class="img" src="pictures/friends2.jpg"  width="100%" >
  <div class="text"><i>Starts Here...</i></div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
<script src="javascript/index.js"></script>


<p class="p1">Welcome to KIIT Alumni Hub</p>
<p class="p2">Let's keep in touch.. <br><br> </p>
<p class="p3">Rekindle Old Friendships: Reconnect with KIIT!

Missing those late-night study sessions, unforgettable gatherings, and exciting events with your KIIT crew? We get it!

KIIT Alumni is here to bridge the gap and reignite those cherished friendships. We understand the value of our global alumni network, and this platform is dedicated to celebrating your achievements and fostering a vibrant community.

Ready to reconnect?

Discover ways to get involved and stay connected with KIIT and its supporters.
Explore upcoming events and services specifically designed for KIIT alumni.
Expanding Our Network:

We strive to stay connected with all our alumni across India and the globe. If you haven't heard from us lately or have a recent address change, please let us know!

Maintaining a database of thousands of graduates is a continuous effort. Your help in keeping your contact information updated ensures we can stay in touch and continue to offer valuable resources.

Join us today and reconnect with your KIIT family! </p>
<br><br><br>
<br /><hr color="#050119" size="4"/>
</div>
<br><br><br>
<div id="howto">
<p class="p1">How to register as a member?</p>
<p class="p2">Steps to become a member of KIIT Alumni...<br><br></p>
</div>
<p class="img2" align="center"><img src="pictures/AlumniDiagram.png"></p>
<br><br><br><br>
</body>
</html>

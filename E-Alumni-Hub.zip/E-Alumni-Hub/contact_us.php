<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact Us</title>
<link rel="stylesheet" href="css/contact_us.css" />

<?php
include_once"setting/contactus_navigation.php";
?>
</head>

<body>
<div id="contact">
<p class="p1">Contact</p>
<p class="p2">Developers of e-Alumni Hub</p>
<p class="p3">KIIT University<br>
Patia, Bhubaneswar, Odisha, India
Pin: 751024<br>
Bhubaneswar<br><br></p>
<table>
<tr>
	<td>
			<p class="p1">Developers Contact:</p>
			<p class="p2">Adway Pratap</p>
      <p class= "p3">Mob: +91 7970980238</p>
      <p class="p3">Email: 2129133@kiit.ac.in</p>
      <p class="p3"> 
   <a href="https://www.instagram.com/adway_is_me/?hl=en">
   <img src="pictures/instagram1.png" width="55" height="40">
  </a> 
  </p>
      <p class="p2">Sreejit Das</p>
      <p class="p3">Mob: +91 79801 03195</p>
      <p class="p3">Email: 2129141@kiit.ac.in</p>
      <p class="p3"> 
   <a href="https://www.instagram.com/thebongtiger/?hl=en">
   <img src="pictures/instagram1.png" width="55" height="40">
  </a> 
      <p class="p2">Shourya Sanyal</p>
      <p class="p3">Mob: +91 6297 615 783</p>
      <p class="p3">Email: 2129105@kiit.ac.in</p>
      <p class="p3"> 
   <a href="https://www.instagram.com/shouryyya_/?hl=en">
   <img src="pictures/instagram1.png" width="55" height="40">
  </a> 
      <p class="p2">Somewrik Bandyopadhyay</p>
      <p class = "p3">  Mob: +91 96355 03191</p>
      <p class="p3">Email: 2129112@kiit.ac.in</p>
      <p class="p3"> 
   <a href="https://www.instagram.com/somwrik._b/?hl=en">
   <img src="pictures/instagram1.png" width="55" height="40">
  </a> 
	</td>		
</tr>
</table>

</div>
<br><br><br>
<br /><hr color="#050119" size="4"/>
<br>
<div id="faq">
<p class="p1">FAQ</p>
<p class="p2"><br>Who are our Alumni?</p>
<p class="p3">All individuals who have followed Diploma, Undergraduate, Postgraduate or PhD of 
the programmes of KIIT Deemed to be University, Bhubaneswar can register as our alumni.</p>
<p class="p2"><br>How do I become a member of the KIIT Deemed to be University Alumni?</p>
<p class="p3">All undergraduates and post graduates of KIIT can register as
 our alumni. It is important for alumni to update their particulars for the KIIT Alumni
  Directory (Database) by register as a member online and pay at the counter of Alumni 
  KIIT so that we can keep in touch with you for life.</p>
<p class="p2"><br>Do I need to pay any fee?</p>

<p class="p3">Yes, but it is only for membership registration. You can choose to pay
 yearly or pay for Life Membership. The fee for yearly paid and lifetime membership are Rs 1000
  and Rs 2000 respectively. </p>
<p class="p2"><br>As an alumni, how can I contribute towards the University?</p>
<p class="p3">You can help by participating in the various activities organized by 
the University or by contributing ideas or programmes towards enriching learning 
experience of all students. Other assistance include donation, sponsorship, expertise
 and volunteer services. Whatever your contribution they are most welcome.</p>
<p class="p2"><br>I am still a student of the University, can I take part in alumni 
activities?</p>
<p class="p3">Yes, of course. We believed that the bond between alumni and students
 should begin as soon as the student enters the University because you will become
  our future alumni later on. The Alumni Advancement is also committed in organising 
  training especially in soft skills and career development programmes to raise your
   employability in the job market upon graduation. We hope this will instill a pride 
   in your alma mater and later on may wish to make whatever contribution towards 
   achieving excellence for the University.
</p>
</div>
<br><br><br><br>
</body>
</html>